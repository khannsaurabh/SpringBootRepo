package com.cg.onnlineshop;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.beans.ProductList;
import com.cg.onlineshop.boot.OnlineShopRestFulSpringBootApplication;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes=OnlineShopRestFulSpringBootApplication.class)
public class CgOnlineShopingRestFulSpringBootApplicationTests {
	@LocalServerPort
	private int port;

	@Autowired
	private TestRestTemplate restTemplate;
	
	@Test
	public void testSayHello() {
		String expecteResponse="Hello World From RestFulWebService";
		String actualResponse=restTemplate.getForObject("http://localhost:" + port + "/sayHello", String.class);
		assertThat(expecteResponse).contains(actualResponse);
	} 
	
	@Test
	public void testAllProductDetailsJSON() throws JsonParseException, JsonMappingException, IOException{
		String jsonData= this.restTemplate.getForObject("http://localhost:" + port + "/allProductDetailsJSON", String.class);
		List<Product> productList = new ObjectMapper().readValue(jsonData,new TypeReference<List<Product>>(){});
		for (Product product : productList) {
			System.out.println(product);
		}
		assertThat(productList !=null);
		assertThat(productList.size()==3);
	}

	@Test
	public void testAllProductDetailsXML(){
		ProductList productList = this.restTemplate.getForObject("http://localhost:" + port + "/allProductDetailsXML", ProductList.class);
		assertThat(productList.products=null);
		assertThat(productList.products.size()==3);
	}
}
