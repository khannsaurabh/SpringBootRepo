package com.cg.onlineshop.daoservices;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.cg.onlineshop.beans.Product;
@Repository(value="onlineShopDAOServices")
@Transactional(propagation=Propagation.REQUIRED)
public class OnlineShopDAOServicesImpl implements OnlineShopDAOServices{

	@PersistenceContext 
	EntityManager entityManager;
	@Override
	public void insertProduct(Product product) {
		entityManager.getTransaction().begin();
		entityManager.persist(product);
		entityManager.getTransaction().commit();
	}
	@Override
	public void updateProduct(Product product) {
	}
	@Override
	public void deleteProduct(int productCode) {
	}
	@Override
	public ArrayList<Product> getAllProducts() {
		return null;
	}
	@Override
	public Product getProduct(int productCode) {
		return entityManager.find(Product.class, productCode);
	}
	@Override
	public void insertBulkProducts(ArrayList<Product> products) {
		// TODO Auto-generated method stub
		
	}

}
