package com.cg.onlineshop;
import static org.assertj.core.api.Assertions.assertThat;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.beans.ProductList;
import com.cg.onlineshop.boot.OnlineShopSpringRestFulSpringBootApplication;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, 
classes=OnlineShopSpringRestFulSpringBootApplication.class)

public class OnlineShopingRestFulSpringBootApplicationTests {
	@LocalServerPort
	private int port;
	@Autowired
	private TestRestTemplate restTemplate;
	private ArrayList<Product> productList;
	
	@Test
	public void testSayHello() {
		String expecteResponse="Hello World From RestFulWebService";
		String actualResponse=restTemplate.getForObject("http://localhost:" + port + "/sayHello", String.class);
		assertThat(expecteResponse).contains(actualResponse);
	} 
	@Before
	public void genrateMokDataForTest(){
		productList = new ArrayList<>();
		productList.add( new Product(111, 12000, "ABC", "Pen"));
		productList.add(new Product(112, 12000, "HP ThinkPad", "Laoptop"));
		productList.add(new Product(113, 50000, "TouchScreen", "mobile"));
	}
	
	@Test
	public void testAllProductDetailsJSON() throws JsonParseException, JsonMappingException, IOException{
		String jsonData= this.restTemplate.getForObject("http://localhost:" + port + "/allProductDetailsJSON", String.class);
		List<Product> productList = new ObjectMapper().readValue(jsonData,new TypeReference<List<Product>>(){});
		for (Product product : productList) {
			System.out.println(product);
		}
		assertThat(productList !=null);
		assertThat(productList.size()==3);
	}

	@Test
	public void testAllProductDetailsXML(){
		ProductList productList = this.restTemplate.getForObject("http://localhost:" + port + "/allProductDetailsXML", ProductList.class);
		assertThat(productList.products=null);
		assertThat(productList.products.size()==3);
	}
}
